import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Home } from "@/pages/Home";
import { GameList } from "@/pages/GameList";
import { GameDetail } from "@/pages/GameDetail";
import { Category } from "@/pages/Category";
import { Search } from "@/pages/Search";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { AdminLogin } from "@/pages/admin/Login";
import { AdminDashboard } from "@/pages/admin/Dashboard";
import { GamesManagement } from "@/pages/admin/GamesManagement";
import { CategoriesManagement } from "@/pages/admin/CategoriesManagement";
import { AdsManagement } from "@/pages/admin/AdsManagement";

function PublicLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Navbar />
      {children}
      <Footer />
    </>
  );
}

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<PublicLayout><Home /></PublicLayout>} />
        <Route path="/games" element={<PublicLayout><GameList /></PublicLayout>} />
        <Route path="/games/:id" element={<PublicLayout><GameDetail /></PublicLayout>} />
        <Route path="/category/:slug" element={<PublicLayout><Category /></PublicLayout>} />
        <Route path="/search" element={<PublicLayout><Search /></PublicLayout>} />
        
        <Route path="/admin/login" element={<AdminLogin />} />
        <Route path="/admin" element={<AdminDashboard />}>
          <Route index element={<div />} />
          <Route path="games" element={<GamesManagement />} />
          <Route path="categories" element={<CategoriesManagement />} />
          <Route path="ads" element={<AdsManagement />} />
        </Route>
      </Routes>
    </Router>
  );
}

import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Gamepad2, Zap, TrendingUp, Sparkles, ArrowRight } from 'lucide-react';
import { GameCard } from '../components/GameCard';
import { useAppStore } from '../store';
import type { Game, Category } from '../types';

export const Home = () => {
  const { games, categories, setGames, setCategories, loading, setLoading } = useAppStore();

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const [gamesRes, categoriesRes] = await Promise.all([
          fetch('/api/games?featured=true'),
          fetch('/api/categories'),
        ]);
        const gamesData = await gamesRes.json();
        const categoriesData = await categoriesRes.json();
        setGames(gamesData);
        setCategories(categoriesData);
      } catch (error) {
        console.error('Failed to fetch data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [setGames, setCategories, setLoading]);

  const popularGames = [...games].sort((a, b) => b.plays - a.plays).slice(0, 8);
  const newGames = [...games].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).slice(0, 8);

  const getCategory = (categoryId: number): Category | undefined => {
    return categories.find(c => c.id === categoryId);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-accent-500 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="flex-1">
      <section className="relative overflow-hidden bg-gradient-to-br from-slate-900 via-primary-900 to-slate-900 py-20">
        <div className="container mx-auto px-4 relative">
          <div className="text-center max-w-4xl mx-auto">
            <div className="inline-flex items-center gap-2 bg-accent-500/20 border border-accent-500/30 rounded-full px-4 py-2 mb-6">
              <Sparkles className="w-4 h-4 text-accent-400" />
              <span className="text-accent-400 text-sm font-medium">100+ Free Games</span>
            </div>
            <h1 className="font-poppins text-5xl md:text-7xl font-extrabold text-white mb-6 leading-tight">
              Play Free Games
              <span className="text-accent-500"> Online</span>
            </h1>
            <p className="text-xl text-slate-300 mb-8 max-w-2xl mx-auto">
              Discover hundreds of amazing free online games. Play instantly in your browser, no downloads required!
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Link
                to="/games"
                className="flex items-center gap-2 px-8 py-4 bg-accent-500 hover:bg-accent-600 text-white rounded-xl font-semibold text-lg transition-all hover:scale-105 shadow-lg shadow-accent-500/30"
              >
                <Gamepad2 className="w-6 h-6" />
                Browse Games
              </Link>
              <Link
                to="#popular"
                className="flex items-center gap-2 px-8 py-4 bg-slate-800 hover:bg-slate-700 text-white rounded-xl font-semibold text-lg transition-all border border-slate-700"
              >
                <TrendingUp className="w-6 h-6" />
                Popular Games
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-slate-900">
        <div className="container mx-auto px-4">
          <h2 className="font-poppins text-3xl font-bold text-white mb-10 text-center">
            Browse by Category
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {categories.map((category) => (
              <Link
                key={category.id}
                to={`/category/${category.slug}`}
                className="group bg-slate-800 hover:bg-slate-700 rounded-xl p-6 text-center transition-all hover:scale-105 border border-slate-700 hover:border-transparent"
                style={{ '--category-color': category.color } as React.CSSProperties}
              >
                <div
                  className="w-12 h-12 mx-auto mb-3 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform"
                  style={{ backgroundColor: `${category.color}20` }}
                >
                  <span style={{ color: category.color }}>
                    <Gamepad2 className="w-6 h-6" />
                  </span>
                </div>
                <h3 className="font-semibold text-white group-hover:text-white transition-colors">
                  {category.name}
                </h3>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section id="popular" className="py-16 bg-slate-950">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-10">
            <div>
              <h2 className="font-poppins text-3xl font-bold text-white flex items-center gap-3">
                <TrendingUp className="w-8 h-8 text-accent-500" />
                Popular Games
              </h2>
              <p className="text-slate-400 mt-2">Most played games this week</p>
            </div>
            <Link
              to="/games"
              className="hidden md:flex items-center gap-2 text-accent-400 hover:text-accent-300 font-medium transition-colors"
            >
              View All <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {popularGames.map((game) => (
              <GameCard
                key={game.id}
                game={game}
                category={getCategory(game.categoryId)}
              />
            ))}
          </div>
          <div className="mt-8 text-center md:hidden">
            <Link
              to="/games"
              className="inline-flex items-center gap-2 text-accent-400 hover:text-accent-300 font-medium transition-colors"
            >
              View All Games <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      <section className="py-16 bg-slate-900">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-10">
            <div>
              <h2 className="font-poppins text-3xl font-bold text-white flex items-center gap-3">
                <Zap className="w-8 h-8 text-yellow-400" />
                New Releases
              </h2>
              <p className="text-slate-400 mt-2">Latest games added to our collection</p>
            </div>
            <Link
              to="/games"
              className="hidden md:flex items-center gap-2 text-accent-400 hover:text-accent-300 font-medium transition-colors"
            >
              View All <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {newGames.map((game) => (
              <GameCard
                key={game.id}
                game={game}
                category={getCategory(game.categoryId)}
              />
            ))}
          </div>
          <div className="mt-8 text-center md:hidden">
            <Link
              to="/games"
              className="inline-flex items-center gap-2 text-accent-400 hover:text-accent-300 font-medium transition-colors"
            >
              View All Games <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

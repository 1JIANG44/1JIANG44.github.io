import { useEffect, useState } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { Search as SearchIcon, ArrowLeft } from 'lucide-react';
import { GameCard } from '../components/GameCard';
import { useAppStore } from '../store';
import type { Game, Category } from '../types';

export const Search = () => {
  const [searchParams] = useSearchParams();
  const query = searchParams.get('q') || '';
  const { games, categories, setGames, setCategories, loading, setLoading } = useAppStore();
  const [searchResults, setSearchResults] = useState<Game[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const [gamesRes, categoriesRes] = await Promise.all([
          fetch(`/api/games?search=${encodeURIComponent(query)}`),
          fetch('/api/categories'),
        ]);
        const gamesData = await gamesRes.json();
        const categoriesData = await categoriesRes.json();
        
        setGames(gamesData);
        setCategories(categoriesData);
        setSearchResults(gamesData);
      } catch (error) {
        console.error('Failed to fetch search results:', error);
      } finally {
        setLoading(false);
      }
    };

    if (query) {
      fetchData();
    }
  }, [query, setGames, setCategories, setLoading]);

  const getCategory = (categoryId: number): Category | undefined => {
    return categories.find(c => c.id === categoryId);
  };

  return (
    <div className="flex-1 py-12 bg-slate-950">
      <div className="container mx-auto px-4">
        <Link
          to="/games"
          className="inline-flex items-center gap-2 text-slate-400 hover:text-white mb-8 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Back to Games
        </Link>

        <div className="mb-10">
          <h1 className="font-poppins text-3xl font-bold text-white mb-4">
            Search Results
          </h1>
          <p className="text-slate-400 text-lg">
            Showing results for: <span className="text-white font-medium">"{query}"</span>
          </p>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="animate-spin rounded-full h-12 w-12 border-4 border-accent-500 border-t-transparent"></div>
          </div>
        ) : searchResults.length === 0 ? (
          <div className="text-center py-20">
            <div className="w-24 h-24 mx-auto mb-6 bg-slate-800 rounded-full flex items-center justify-center">
              <SearchIcon className="w-12 h-12 text-slate-600" />
            </div>
            <h2 className="text-2xl font-semibold text-white mb-2">No results found</h2>
            <p className="text-slate-400 mb-6">Try using different keywords or browse our categories</p>
            <Link
              to="/games"
              className="inline-flex items-center gap-2 px-6 py-3 bg-accent-500 hover:bg-accent-600 text-white rounded-lg font-medium transition-colors"
            >
              Browse All Games
            </Link>
          </div>
        ) : (
          <>
            <p className="text-slate-400 mb-6">
              Found {searchResults.length} game{searchResults.length !== 1 ? 's' : ''}
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {searchResults.map((game) => (
                <GameCard
                  key={game.id}
                  game={game}
                  category={getCategory(game.categoryId)}
                />
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
};

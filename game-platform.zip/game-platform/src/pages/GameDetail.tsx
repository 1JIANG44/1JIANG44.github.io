import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Play, Eye, Star, Share2, Heart, Maximize2 } from 'lucide-react';
import { GameCard } from '../components/GameCard';
import { useAppStore } from '../store';
import type { Game, Category } from '../types';

export const GameDetail = () => {
  const { id } = useParams<{ id: string }>();
  const { games, categories, setGames, setCategories, loading, setLoading } = useAppStore();
  const [game, setGame] = useState<Game | null>(null);
  const [similarGames, setSimilarGames] = useState<Game[]>([]);
  const [isFullscreen, setIsFullscreen] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const [gameRes, gamesRes, categoriesRes] = await Promise.all([
          fetch(`/api/games/${id}`),
          fetch('/api/games'),
          fetch('/api/categories'),
        ]);
        const gameData = await gameRes.json();
        const gamesData = await gamesRes.json();
        const categoriesData = await categoriesRes.json();

        setGame(gameData);
        setGames(gamesData);
        setCategories(categoriesData);

        const similar = gamesData.filter(
          (g: Game) => g.id !== gameData.id && g.categoryId === gameData.categoryId && g.active
        ).slice(0, 6);
        setSimilarGames(similar);

        await fetch(`/api/games/${id}/play`, { method: 'POST' });
      } catch (error) {
        console.error('Failed to fetch game:', error);
      } finally {
        setLoading(false);
      }
    };

    if (id) {
      fetchData();
    }
  }, [id, setGames, setCategories, setLoading]);

  const getCategory = (categoryId: number): Category | undefined => {
    return categories.find(c => c.id === categoryId);
  };

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-accent-500 border-t-transparent"></div>
      </div>
    );
  }

  if (!game) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-white mb-2">Game not found</h1>
          <Link to="/games" className="text-accent-400 hover:text-accent-300">
            Back to all games
          </Link>
        </div>
      </div>
    );
  }

  const category = getCategory(game.categoryId);

  return (
    <div className="flex-1 bg-slate-950">
      {!isFullscreen && (
        <div className="container mx-auto px-4 py-6">
          <Link
            to="/games"
            className="inline-flex items-center gap-2 text-slate-400 hover:text-white mb-6 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Games
          </Link>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <div className="mb-6">
                <h1 className="font-poppins text-4xl font-bold text-white mb-4">{game.title}</h1>
                <div className="flex flex-wrap items-center gap-4">
                  {category && (
                    <span
                      className="px-3 py-1 rounded-full text-sm font-medium"
                      style={{ backgroundColor: `${category.color}20`, color: category.color }}
                    >
                      {category.name}
                    </span>
                  )}
                  <div className="flex items-center gap-1 text-slate-400">
                    <Eye className="w-5 h-5" />
                    <span>{game.plays.toLocaleString()} plays</span>
                  </div>
                  <div className="flex items-center gap-1 text-yellow-400">
                    <Star className="w-5 h-5 fill-current" />
                    <span>{game.rating.toFixed(1)}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="lg:col-span-1">
              <div className="bg-slate-900 rounded-xl p-6 border border-slate-800">
                <h3 className="font-semibold text-white mb-4">Game Info</h3>
                <p className="text-slate-400 mb-6">{game.description}</p>
                <div className="flex gap-3">
                  <button className="flex-1 flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg px-4 py-3 transition-colors">
                    <Heart className="w-5 h-5" />
                    Favorite
                  </button>
                  <button className="flex-1 flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg px-4 py-3 transition-colors">
                    <Share2 className="w-5 h-5" />
                    Share
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className={`${isFullscreen ? 'fixed inset-0 z-50 bg-black' : ''}`}>
        <div className={`${isFullscreen ? 'h-full' : 'container mx-auto px-4'}`}>
          <div className="bg-slate-900 rounded-xl overflow-hidden relative">
            {!isFullscreen && (
              <div className="absolute top-4 right-4 z-10">
                <button
                  onClick={toggleFullscreen}
                  className="bg-black/50 hover:bg-black/70 text-white p-2 rounded-lg backdrop-blur-sm transition-colors"
                >
                  <Maximize2 className="w-6 h-6" />
                </button>
              </div>
            )}
            {isFullscreen && (
              <div className="absolute top-4 right-4 z-10">
                <button
                  onClick={toggleFullscreen}
                  className="bg-black/50 hover:bg-black/70 text-white p-2 rounded-lg backdrop-blur-sm transition-colors"
                >
                  <Maximize2 className="w-6 h-6" />
                </button>
              </div>
            )}
            <iframe
              src={game.gameUrl}
              title={game.title}
              className={`w-full ${isFullscreen ? 'h-full' : 'aspect-video'}`}
              allowFullScreen
              allow="fullscreen"
            />
          </div>
        </div>
      </div>

      {!isFullscreen && similarGames.length > 0 && (
        <div className="container mx-auto px-4 py-12">
          <h2 className="font-poppins text-2xl font-bold text-white mb-6">Similar Games</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {similarGames.map((g) => (
              <GameCard
                key={g.id}
                game={g}
                category={getCategory(g.categoryId)}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

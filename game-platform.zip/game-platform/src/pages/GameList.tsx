import { useEffect, useState } from 'react';
import { Filter, Search, ArrowUpDown } from 'lucide-react';
import { GameCard } from '../components/GameCard';
import { useAppStore } from '../store';
import type { Game, Category } from '../types';

export const GameList = () => {
  const { games, categories, setGames, setCategories, loading, setLoading } = useAppStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [sortBy, setSortBy] = useState<string>('popular');

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        let gamesUrl = '/api/games';
        const params = new URLSearchParams();
        if (selectedCategory) params.append('category', selectedCategory);
        if (sortBy) params.append('sort', sortBy);
        if (params.toString()) gamesUrl += `?${params.toString()}`;

        const [gamesRes, categoriesRes] = await Promise.all([
          fetch(gamesUrl),
          fetch('/api/categories'),
        ]);
        const gamesData = await gamesRes.json();
        const categoriesData = await categoriesRes.json();
        setGames(gamesData);
        setCategories(categoriesData);
      } catch (error) {
        console.error('Failed to fetch data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [setGames, setCategories, setLoading, selectedCategory, sortBy]);

  const filteredGames = games.filter((game) =>
    game.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    game.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getCategory = (categoryId: number): Category | undefined => {
    return categories.find(c => c.id === categoryId);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-accent-500 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="flex-1 py-12 bg-slate-950">
      <div className="container mx-auto px-4">
        <div className="mb-10">
          <h1 className="font-poppins text-4xl font-bold text-white mb-4">All Games</h1>
          <p className="text-slate-400 text-lg">Browse our complete collection of free online games</p>
        </div>

        <div className="bg-slate-900 rounded-xl p-6 mb-8 border border-slate-800">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input
                type="text"
                placeholder="Search games..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-10 pr-4 py-3 text-white placeholder-slate-400 focus:outline-none focus:border-primary-500"
              />
            </div>

            <div className="relative">
              <Filter className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-10 pr-4 py-3 text-white focus:outline-none focus:border-primary-500 appearance-none cursor-pointer"
              >
                <option value="">All Categories</option>
                {categories.map((category) => (
                  <option key={category.id} value={category.id.toString()}>
                    {category.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="relative">
              <ArrowUpDown className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-10 pr-4 py-3 text-white focus:outline-none focus:border-primary-500 appearance-none cursor-pointer"
              >
                <option value="popular">Most Popular</option>
                <option value="newest">Newest First</option>
                <option value="rating">Highest Rated</option>
              </select>
            </div>
          </div>
        </div>

        {filteredGames.length === 0 ? (
          <div className="text-center py-20">
            <div className="w-24 h-24 mx-auto mb-6 bg-slate-800 rounded-full flex items-center justify-center">
              <Search className="w-12 h-12 text-slate-600" />
            </div>
            <h2 className="text-2xl font-semibold text-white mb-2">No games found</h2>
            <p className="text-slate-400">Try adjusting your search or filter criteria</p>
          </div>
        ) : (
          <>
            <p className="text-slate-400 mb-6">
              Showing {filteredGames.length} game{filteredGames.length !== 1 ? 's' : ''}
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredGames.map((game) => (
                <GameCard
                  key={game.id}
                  game={game}
                  category={getCategory(game.categoryId)}
                />
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
};

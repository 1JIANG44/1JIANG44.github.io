import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { GameCard } from '../components/GameCard';
import { useAppStore } from '../store';
import type { Game, Category as CategoryType } from '../types';

export const Category = () => {
  const { slug } = useParams<{ slug: string }>();
  const { categories, setCategories, loading, setLoading } = useAppStore();
  const [categoryData, setCategoryData] = useState<{ category: CategoryType; games: Game[] } | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const [categoryRes, categoriesRes] = await Promise.all([
          fetch(`/api/categories/slug/${slug}`),
          fetch('/api/categories'),
        ]);
        const categoryData = await categoryRes.json();
        const categoriesData = await categoriesRes.json();
        
        setCategoryData(categoryData);
        setCategories(categoriesData);
      } catch (error) {
        console.error('Failed to fetch category:', error);
      } finally {
        setLoading(false);
      }
    };

    if (slug) {
      fetchData();
    }
  }, [slug, setCategories, setLoading]);

  const getCategory = (categoryId: number): CategoryType | undefined => {
    return categories.find(c => c.id === categoryId);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-accent-500 border-t-transparent"></div>
      </div>
    );
  }

  if (!categoryData) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-white mb-2">Category not found</h1>
          <Link to="/games" className="text-accent-400 hover:text-accent-300">
            Back to all games
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 py-12 bg-slate-950">
      <div className="container mx-auto px-4">
        <Link
          to="/games"
          className="inline-flex items-center gap-2 text-slate-400 hover:text-white mb-8 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Back to Games
        </Link>

        <div className="mb-10">
          <div
            className="inline-flex items-center gap-3 px-6 py-3 rounded-xl mb-4"
            style={{ backgroundColor: `${categoryData.category.color}20` }}
          >
            <span style={{ color: categoryData.category.color }}>
              <h1 className="font-poppins text-3xl font-bold">{categoryData.category.name} Games</h1>
            </span>
          </div>
          <p className="text-slate-400 text-lg">
            Browse our collection of {categoryData.games.length} {categoryData.category.name.toLowerCase()} games
          </p>
        </div>

        {categoryData.games.length === 0 ? (
          <div className="text-center py-20">
            <h2 className="text-2xl font-semibold text-white mb-2">No games in this category</h2>
            <p className="text-slate-400">Check back soon for new games!</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {categoryData.games.map((game) => (
              <GameCard
                key={game.id}
                game={game}
                category={getCategory(game.categoryId)}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

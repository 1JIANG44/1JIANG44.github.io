import { useEffect, useState } from 'react';
import { Link, useNavigate, Outlet } from 'react-router-dom';
import {
  LayoutDashboard,
  Gamepad2,
  Tag,
  DollarSign,
  BarChart3,
  LogOut,
  Menu,
  X,
  TrendingUp,
  Play,
  Zap,
} from 'lucide-react';
import { useAppStore } from '../../store';

interface Stats {
  totalPlays: number;
  totalGames: number;
  totalCategories: number;
  popularGames: any[];
}

export const AdminDashboard = () => {
  const { isAuthenticated, logout } = useAppStore();
  const navigate = useNavigate();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [stats, setStats] = useState<Stats | null>(null);

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/admin/login');
    }
  }, [isAuthenticated, navigate]);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const res = await fetch('/api/stats');
        const data = await res.json();
        setStats(data);
      } catch (error) {
        console.error('Failed to fetch stats:', error);
      }
    };

    if (isAuthenticated) {
      fetchStats();
    }
  }, [isAuthenticated]);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const navItems = [
    { path: '/admin', label: 'Dashboard', icon: LayoutDashboard },
    { path: '/admin/games', label: 'Games', icon: Gamepad2 },
    { path: '/admin/categories', label: 'Categories', icon: Tag },
    { path: '/admin/ads', label: 'Ads', icon: DollarSign },
  ];

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-slate-950 flex">
      <div className={`fixed inset-y-0 left-0 z-50 w-64 bg-slate-900 border-r border-slate-800 transform transition-transform duration-300 lg:translate-x-0 ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="p-6">
          <Link to="/" className="flex items-center gap-2 mb-8">
            <Gamepad2 className="w-8 h-8 text-accent-500" />
            <span className="font-poppins font-bold text-xl text-white">
              Game<span className="text-accent-500">Hub</span>
            </span>
          </Link>

          <nav className="space-y-2">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => setIsSidebarOpen(false)}
                className="flex items-center gap-3 px-4 py-3 rounded-lg text-slate-300 hover:bg-slate-800 hover:text-white transition-colors"
              >
                <item.icon className="w-5 h-5" />
                <span className="font-medium">{item.label}</span>
              </Link>
            ))}
          </nav>
        </div>

        <div className="absolute bottom-0 left-0 right-0 p-6">
          <button
            onClick={handleLogout}
            className="flex items-center gap-3 w-full px-4 py-3 rounded-lg text-slate-300 hover:bg-red-500/10 hover:text-red-400 transition-colors"
          >
            <LogOut className="w-5 h-5" />
            <span className="font-medium">Logout</span>
          </button>
        </div>
      </div>

      {isSidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      <div className="flex-1 lg:ml-64">
        <header className="bg-slate-900 border-b border-slate-800 px-6 py-4">
          <div className="flex items-center justify-between">
            <button
              onClick={() => setIsSidebarOpen(true)}
              className="lg:hidden text-slate-400 hover:text-white"
            >
              <Menu className="w-6 h-6" />
            </button>
            <h2 className="font-poppins text-xl font-bold text-white hidden lg:block">Admin Dashboard</h2>
            <div className="flex items-center gap-4">
              <Link
                to="/"
                className="text-slate-400 hover:text-white transition-colors"
              >
                View Site
              </Link>
            </div>
          </div>
        </header>

        <main className="p-6">
          <Outlet />

          {stats && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="bg-slate-900 rounded-xl p-6 border border-slate-800">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 bg-primary-500/20 rounded-lg flex items-center justify-center">
                    <Play className="w-6 h-6 text-primary-400" />
                  </div>
                </div>
                <h3 className="text-3xl font-bold text-white mb-1">{stats.totalPlays.toLocaleString()}</h3>
                <p className="text-slate-400">Total Plays</p>
              </div>

              <div className="bg-slate-900 rounded-xl p-6 border border-slate-800">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 bg-accent-500/20 rounded-lg flex items-center justify-center">
                    <Gamepad2 className="w-6 h-6 text-accent-400" />
                  </div>
                </div>
                <h3 className="text-3xl font-bold text-white mb-1">{stats.totalGames}</h3>
                <p className="text-slate-400">Total Games</p>
              </div>

              <div className="bg-slate-900 rounded-xl p-6 border border-slate-800">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 bg-purple-500/20 rounded-lg flex items-center justify-center">
                    <Tag className="w-6 h-6 text-purple-400" />
                  </div>
                </div>
                <h3 className="text-3xl font-bold text-white mb-1">{stats.totalCategories}</h3>
                <p className="text-slate-400">Categories</p>
              </div>
            </div>
          )}

          {stats && stats.popularGames.length > 0 && (
            <div className="bg-slate-900 rounded-xl border border-slate-800">
              <div className="p-6 border-b border-slate-800">
                <h3 className="font-poppins text-lg font-semibold text-white flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-accent-500" />
                  Popular Games
                </h3>
              </div>
              <div className="divide-y divide-slate-800">
                {stats.popularGames.map((game, index) => (
                  <div key={game.id} className="p-6 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <span className="w-8 h-8 bg-slate-800 rounded-lg flex items-center justify-center text-slate-400 font-semibold">
                        {index + 1}
                      </span>
                      <div>
                        <h4 className="font-medium text-white">{game.title}</h4>
                        <p className="text-sm text-slate-400">{game.plays.toLocaleString()} plays</p>
                      </div>
                    </div>
                    <Zap className="w-5 h-5 text-yellow-400" />
                  </div>
                ))}
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

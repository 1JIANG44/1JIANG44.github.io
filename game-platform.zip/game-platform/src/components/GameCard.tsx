import { Link } from 'react-router-dom';
import { Play, Eye, Star } from 'lucide-react';
import type { Game, Category } from '../types';

interface GameCardProps {
  game: Game;
  category?: Category;
}

export const GameCard = ({ game, category }: GameCardProps) => {
  return (
    <Link
      to={`/games/${game.id}`}
      className="group relative bg-slate-800 rounded-xl overflow-hidden transition-all duration-300 hover:scale-[1.02] hover:shadow-2xl hover:shadow-primary-500/20"
    >
      <div className="aspect-[4/3] overflow-hidden">
        <img
          src={game.thumbnailUrl}
          alt={game.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <div className="w-16 h-16 bg-accent-500 rounded-full flex items-center justify-center shadow-lg">
            <Play className="w-8 h-8 text-white fill-current" />
          </div>
        </div>
      </div>
      <div className="p-4">
        <div className="flex items-start justify-between mb-2">
          <h3 className="font-poppins font-semibold text-white text-lg line-clamp-1">
            {game.title}
          </h3>
        </div>
        <div className="flex items-center gap-3 text-sm text-slate-400">
          {category && (
            <span
              className="px-2 py-1 rounded-full text-xs font-medium"
              style={{ backgroundColor: `${category.color}20`, color: category.color }}
            >
              {category.name}
            </span>
          )}
          <div className="flex items-center gap-1">
            <Eye className="w-4 h-4" />
            <span>{game.plays.toLocaleString()}</span>
          </div>
          <div className="flex items-center gap-1">
            <Star className="w-4 h-4 text-yellow-400 fill-current" />
            <span>{game.rating.toFixed(1)}</span>
          </div>
        </div>
      </div>
    </Link>
  );
};

import { Gamepad2 } from 'lucide-react';
import { Link } from 'react-router-dom';

export const Footer = () => {
  return (
    <footer className="bg-slate-900 border-t border-slate-800 mt-auto">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-1">
            <Link to="/" className="flex items-center gap-2 mb-4">
              <Gamepad2 className="w-8 h-8 text-accent-500" />
              <span className="font-poppins font-bold text-2xl text-white">
                Game<span className="text-accent-500">Hub</span>
              </span>
            </Link>
            <p className="text-slate-400 text-sm">
              Your destination for the best free online games. Play hundreds of games instantly!
            </p>
          </div>
          <div>
            <h4 className="font-semibold text-white mb-4">Categories</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/category/arcade" className="text-slate-400 hover:text-white text-sm transition-colors">
                  Arcade
                </Link>
              </li>
              <li>
                <Link to="/category/puzzle" className="text-slate-400 hover:text-white text-sm transition-colors">
                  Puzzle
                </Link>
              </li>
              <li>
                <Link to="/category/brain" className="text-slate-400 hover:text-white text-sm transition-colors">
                  Brain
                </Link>
              </li>
              <li>
                <Link to="/category/action" className="text-slate-400 hover:text-white text-sm transition-colors">
                  Action
                </Link>
              </li>
              <li>
                <Link to="/category/sports" className="text-slate-400 hover:text-white text-sm transition-colors">
                  Sports
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold text-white mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/games" className="text-slate-400 hover:text-white text-sm transition-colors">
                  All Games
                </Link>
              </li>
              <li>
                <Link to="/" className="text-slate-400 hover:text-white text-sm transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/admin" className="text-slate-400 hover:text-white text-sm transition-colors">
                  Admin
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold text-white mb-4">Legal</h4>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-slate-400 hover:text-white text-sm transition-colors">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="#" className="text-slate-400 hover:text-white text-sm transition-colors">
                  Terms of Service
                </a>
              </li>
              <li>
                <a href="#" className="text-slate-400 hover:text-white text-sm transition-colors">
                  Cookie Policy
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div className="border-t border-slate-800 mt-8 pt-8 text-center text-slate-500 text-sm">
          <p>&copy; 2024 GameHub. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

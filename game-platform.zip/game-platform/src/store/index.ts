import { create } from 'zustand';
import type { Game, Category, Ad } from '../types';

interface AppStore {
  games: Game[];
  categories: Category[];
  ads: Ad[];
  loading: boolean;
  error: string | null;
  isAuthenticated: boolean;
  setGames: (games: Game[]) => void;
  setCategories: (categories: Category[]) => void;
  setAds: (ads: Ad[]) => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  login: (password: string) => boolean;
  logout: () => void;
}

const ADMIN_PASSWORD = '486191546';

export const useAppStore = create<AppStore>((set) => ({
  games: [],
  categories: [],
  ads: [],
  loading: false,
  error: null,
  isAuthenticated: false,
  setGames: (games) => set({ games }),
  setCategories: (categories) => set({ categories }),
  setAds: (ads) => set({ ads }),
  setLoading: (loading) => set({ loading }),
  setError: (error) => set({ error }),
  login: (password) => {
    if (password === ADMIN_PASSWORD) {
      set({ isAuthenticated: true });
      return true;
    }
    return false;
  },
  logout: () => set({ isAuthenticated: false }),
}));

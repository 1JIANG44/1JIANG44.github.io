export interface Game {
  id: number;
  title: string;
  description: string;
  thumbnailUrl: string;
  gameUrl: string;
  categoryId: number;
  plays: number;
  rating: number;
  featured: boolean;
  active: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Category {
  id: number;
  name: string;
  slug: string;
  icon: string;
  color: string;
  createdAt: string;
}

export interface Ad {
  id: number;
  name: string;
  placement: string;
  adCode: string;
  network: string;
  active: boolean;
  createdAt: string;
}

export interface Database {
  games: Game[];
  categories: Category[];
  ads: Ad[];
}

# GameHub Deployment Guide

This guide will help you deploy GameHub to various hosting platforms.

## Prerequisites

- A GitHub account
- Node.js 18+ installed locally

## Option 1: Deploy to Vercel (Recommended)

Vercel provides the easiest deployment experience for Vite + Express applications.

### Steps:

1. **Push your code to GitHub**

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/your-username/gamehub.git
git push -u origin main
```

2. **Sign up for Vercel**
   - Go to [vercel.com](https://vercel.com)
   - Sign up with your GitHub account

3. **Import your project**
   - Click "New Project" in Vercel dashboard
   - Select your GameHub repository
   - Click "Import"

4. **Configure project settings**
   - Framework Preset: Vite
   - Root Directory: ./
   - Build Command: `npm run build`
   - Output Directory: `dist`

5. **Deploy!**
   - Click "Deploy"
   - Wait for the deployment to complete (usually 1-2 minutes)
   - Your site will be live at `https://gamehub-xyz.vercel.app`

## Option 2: Deploy to Netlify

Netlify also provides excellent static hosting with serverless functions.

### Steps:

1. **Push your code to GitHub** (same as Vercel)

2. **Sign up for Netlify**
   - Go to [netlify.com](https://netlify.com)
   - Sign up with your GitHub account

3. **Import your project**
   - Click "Add new site" → "Import an existing project"
   - Connect to GitHub
   - Select your repository

4. **Configure build settings**
   - Build command: `npm run build`
   - Publish directory: `dist`

5. **Deploy!**

## Option 3: Deploy to GitHub Pages

GitHub Pages is free but requires some extra setup.

### Steps:

1. **Install gh-pages package**

```bash
npm install --save-dev gh-pages
```

2. **Add deploy script to package.json**

```json
{
  "scripts": {
    "predeploy": "npm run build",
    "deploy": "gh-pages -d dist"
  }
}
```

3. **Push to GitHub and deploy**

```bash
npm run deploy
```

## Important Notes for Production Deployment

### Database Considerations

The current implementation uses a JSON file for the database. For production, you should:

1. **Use a real database**:
   - PostgreSQL (free tier on Supabase, Vercel Postgres)
   - MongoDB (free tier on MongoDB Atlas)
   - MySQL (free tier on PlanetScale)

2. **Update backend controllers** to use the new database

### Environment Variables

Create a `.env` file in your project root (never commit this file!):

```env
PORT=3001
ADMIN_PASSWORD=your-secure-admin-password
DATABASE_URL=your-database-connection-string
```

### Security Best Practices

1. **Change the admin password** from the default `486191546`
2. **Use HTTPS** (all the above platforms provide this by default)
3. **Set up CORS properly** for your domain
4. **Add rate limiting** to prevent abuse
5. **Use environment variables** for all secrets

### Game Integration

For production:
- Use games that you have legal rights to host
- Consider using iframe embeds from trusted game platforms
- Always respect copyright and licensing terms

## Troubleshooting

### Build fails on Vercel
- Check that all dependencies are in `package.json`
- Ensure `package.json` has the correct `type: "module"`
- Check the build logs for specific errors

### API routes not working
- Verify Vercel/Netlify configuration for serverless functions
- Check that API files are in the correct directory

### Database not persisting
- Remember that serverless environments don't persist file changes
- You must use a real database for production

## Need Help?

- Vercel Docs: https://vercel.com/docs
- Netlify Docs: https://docs.netlify.com
- GitHub Pages Docs: https://pages.github.com

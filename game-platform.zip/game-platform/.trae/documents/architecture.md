# GameHub - Technical Architecture

## 1. Architecture Design

```mermaid
flowchart TB
    subgraph Frontend["Frontend (React + TypeScript)"]
        Pages["Pages (Home, Game List, Game Detail, Admin)"]
        Components["Reusable Components (GameCard, Navbar, Sidebar)"]
        State["State Management (Zustand)"]
        Routing["Routing (React Router)"]
    end
    
    subgraph Backend["Backend (Express + TypeScript)"]
        Controllers["Controllers (Games, Categories, Ads)"]
        Services["Services (Data Management, Statistics)"]
        Middleware["Middleware (CORS, Auth)"]
    end
    
    subgraph Database["Database (JSON File / SQLite)"]
        GamesTable["Games"]
        CategoriesTable["Categories"]
        AdsTable["Ads"]
        StatsTable["Statistics"]
    end
    
    Frontend -->|API Calls| Backend
    Backend -->|Read/Write| Database
```

## 2. Technology Description
- **Frontend**: React@18 + TypeScript + Vite + Tailwind CSS + Zustand + React Router
- **Initialization Tool**: vite-init with react-express-ts template
- **Backend**: Express@4 + TypeScript
- **Database**: Local JSON file storage (easily scalable to SQLite/PostgreSQL)
- **Icons**: Lucide React
- **Styling**: Tailwind CSS with custom theme
- **Animations**: CSS transitions + Framer Motion

## 3. Route Definitions

### Frontend Routes
| Route | Purpose |
|-------|---------|
| / | Home page with featured games and categories |
| /games | All games list with filtering |
| /games/:id | Game detail and play page |
| /category/:slug | Games by category |
| /search | Search results page |
| /admin | Admin dashboard (protected) |
| /admin/login | Admin login page |
| /admin/games | Game management |
| /admin/categories | Category management |
| /admin/ads | Ad management |
| /admin/stats | Statistics dashboard |

### Backend API Routes
| Route | Method | Purpose |
|-------|--------|---------|
| /api/games | GET | Get all games |
| /api/games/:id | GET | Get game by ID |
| /api/games | POST | Create game (admin) |
| /api/games/:id | PUT | Update game (admin) |
| /api/games/:id | DELETE | Delete game (admin) |
| /api/games/:id/play | POST | Increment play count |
| /api/categories | GET | Get all categories |
| /api/categories | POST | Create category (admin) |
| /api/categories/:id | PUT | Update category (admin) |
| /api/categories/:id | DELETE | Delete category (admin) |
| /api/ads | GET | Get active ads |
| /api/ads | POST | Create ad (admin) |
| /api/ads/:id | PUT | Update ad (admin) |
| /api/ads/:id | DELETE | Delete ad (admin) |
| /api/stats | GET | Get platform statistics |

## 4. Data Model

### 4.1 Data Model Definition

```mermaid
erDiagram
    GAMES {
        number id
        string title
        string description
        string thumbnailUrl
        string gameUrl
        string categoryId
        number plays
        number rating
        boolean featured
        boolean active
        date createdAt
        date updatedAt
    }
    
    CATEGORIES {
        number id
        string name
        string slug
        string icon
        string color
        date createdAt
    }
    
    ADS {
        number id
        string name
        string placement
        string adCode
        string network
        boolean active
        date createdAt
    }
    
    CATEGORIES ||--o{ GAMES : contains
```

### 4.2 Data Structure (JSON File)

```typescript
// Database structure
interface Database {
  games: Game[];
  categories: Category[];
  ads: Ad[];
}

interface Game {
  id: number;
  title: string;
  description: string;
  thumbnailUrl: string;
  gameUrl: string;
  categoryId: number;
  plays: number;
  rating: number;
  featured: boolean;
  active: boolean;
  createdAt: string;
  updatedAt: string;
}

interface Category {
  id: number;
  name: string;
  slug: string;
  icon: string;
  color: string;
  createdAt: string;
}

interface Ad {
  id: number;
  name: string;
  placement: 'header' | 'sidebar' | 'game-top' | 'game-bottom' | 'interstitial';
  adCode: string;
  network: string;
  active: boolean;
  createdAt: string;
}
```

## 5. Project Structure

```
/workspace
├── src/                    # Frontend source
│   ├── components/        # Reusable components
│   │   ├── GameCard.tsx
│   │   ├── Navbar.tsx
│   │   ├── Footer.tsx
│   │   └── ...
│   ├── pages/            # Page components
│   │   ├── Home.tsx
│   │   ├── GameList.tsx
│   │   ├── GameDetail.tsx
│   │   └── admin/
│   │       ├── Dashboard.tsx
│   │       ├── GameManagement.tsx
│   │       └── ...
│   ├── hooks/            # Custom hooks
│   ├── store/            # Zustand store
│   ├── types/            # TypeScript types
│   └── utils/            # Utility functions
├── api/                  # Backend source
│   ├── controllers/      # API controllers
│   ├── routes/          # API routes
│   ├── middleware/      # Express middleware
│   └── data/            # Database file
└── public/              # Static assets
    └── games/           # Game files
```

## 6. Key Implementation Decisions

1. **Data Storage**: Use JSON file for simplicity and easy setup, with clear path to migrate to SQLite/PostgreSQL
2. **State Management**: Zustand for lightweight, simple state management
3. **Styling**: Tailwind CSS for rapid development with custom gaming theme
4. **Authentication**: Simple admin password authentication (can be upgraded later)
5. **Game Integration**: iframe-based game embedding for maximum compatibility with open-source web games
6. **Ad Integration**: Support for multiple ad networks with configurable placements
7. **Responsive Design**: Mobile-first with touch-friendly controls

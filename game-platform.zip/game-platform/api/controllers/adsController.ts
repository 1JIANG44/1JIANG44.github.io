import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import type { Request, Response } from 'express';
import type { Ad, Database } from '../../src/types';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DB_PATH = path.join(__dirname, '../data/database.json');

const readDB = (): Database => {
  const data = fs.readFileSync(DB_PATH, 'utf-8');
  return JSON.parse(data);
};

const writeDB = (db: Database) => {
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
};

export const getAds = (req: Request, res: Response) => {
  try {
    const db = readDB();
    const { placement } = req.query;
    
    let ads = db.ads.filter(a => a.active);
    
    if (placement) {
      ads = ads.filter(a => a.placement === placement);
    }
    
    res.json(ads);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch ads' });
  }
};

export const createAd = (req: Request, res: Response) => {
  try {
    const db = readDB();
    const newAd: Ad = {
      id: Math.max(0, ...db.ads.map(a => a.id)) + 1,
      ...req.body,
      active: true,
      createdAt: new Date().toISOString(),
    };
    
    db.ads.push(newAd);
    writeDB(db);
    
    res.status(201).json(newAd);
  } catch (error) {
    res.status(500).json({ error: 'Failed to create ad' });
  }
};

export const updateAd = (req: Request, res: Response) => {
  try {
    const db = readDB();
    const index = db.ads.findIndex(a => a.id === parseInt(req.params.id));
    
    if (index === -1) {
      return res.status(404).json({ error: 'Ad not found' });
    }
    
    db.ads[index] = {
      ...db.ads[index],
      ...req.body,
    };
    
    writeDB(db);
    res.json(db.ads[index]);
  } catch (error) {
    res.status(500).json({ error: 'Failed to update ad' });
  }
};

export const deleteAd = (req: Request, res: Response) => {
  try {
    const db = readDB();
    const index = db.ads.findIndex(a => a.id === parseInt(req.params.id));
    
    if (index === -1) {
      return res.status(404).json({ error: 'Ad not found' });
    }
    
    db.ads.splice(index, 1);
    writeDB(db);
    
    res.json({ message: 'Ad deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete ad' });
  }
};

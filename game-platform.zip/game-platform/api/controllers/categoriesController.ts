import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import type { Request, Response } from 'express';
import type { Category, Database } from '../../src/types';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DB_PATH = path.join(__dirname, '../data/database.json');

const readDB = (): Database => {
  const data = fs.readFileSync(DB_PATH, 'utf-8');
  return JSON.parse(data);
};

const writeDB = (db: Database) => {
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
};

export const getCategories = (req: Request, res: Response) => {
  try {
    const db = readDB();
    res.json(db.categories);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch categories' });
  }
};

export const getCategoryBySlug = (req: Request, res: Response) => {
  try {
    const db = readDB();
    const category = db.categories.find(c => c.slug === req.params.slug);
    
    if (!category) {
      return res.status(404).json({ error: 'Category not found' });
    }
    
    const games = db.games.filter(g => g.categoryId === category.id && g.active);
    
    res.json({ category, games });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch category' });
  }
};

export const createCategory = (req: Request, res: Response) => {
  try {
    const db = readDB();
    const newCategory: Category = {
      id: Math.max(0, ...db.categories.map(c => c.id)) + 1,
      ...req.body,
      createdAt: new Date().toISOString(),
    };
    
    db.categories.push(newCategory);
    writeDB(db);
    
    res.status(201).json(newCategory);
  } catch (error) {
    res.status(500).json({ error: 'Failed to create category' });
  }
};

export const updateCategory = (req: Request, res: Response) => {
  try {
    const db = readDB();
    const index = db.categories.findIndex(c => c.id === parseInt(req.params.id));
    
    if (index === -1) {
      return res.status(404).json({ error: 'Category not found' });
    }
    
    db.categories[index] = {
      ...db.categories[index],
      ...req.body,
    };
    
    writeDB(db);
    res.json(db.categories[index]);
  } catch (error) {
    res.status(500).json({ error: 'Failed to update category' });
  }
};

export const deleteCategory = (req: Request, res: Response) => {
  try {
    const db = readDB();
    const index = db.categories.findIndex(c => c.id === parseInt(req.params.id));
    
    if (index === -1) {
      return res.status(404).json({ error: 'Category not found' });
    }
    
    db.categories.splice(index, 1);
    writeDB(db);
    
    res.json({ message: 'Category deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete category' });
  }
};

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import type { Request, Response } from 'express';
import type { Game, Database } from '../../src/types';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DB_PATH = path.join(__dirname, '../data/database.json');

const readDB = (): Database => {
  const data = fs.readFileSync(DB_PATH, 'utf-8');
  return JSON.parse(data);
};

const writeDB = (db: Database) => {
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
};

export const getGames = (req: Request, res: Response) => {
  try {
    const db = readDB();
    const { category, search, sort, featured } = req.query;
    
    let games = db.games.filter(g => g.active);
    
    if (category) {
      const categoryId = parseInt(category as string);
      games = games.filter(g => g.categoryId === categoryId);
    }
    
    if (search) {
      const searchTerm = (search as string).toLowerCase();
      games = games.filter(g => 
        g.title.toLowerCase().includes(searchTerm) || 
        g.description.toLowerCase().includes(searchTerm)
      );
    }
    
    if (featured === 'true') {
      games = games.filter(g => g.featured);
    }
    
    if (sort) {
      switch (sort) {
        case 'popular':
          games.sort((a, b) => b.plays - a.plays);
          break;
        case 'newest':
          games.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
          break;
        case 'rating':
          games.sort((a, b) => b.rating - a.rating);
          break;
      }
    }
    
    res.json(games);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch games' });
  }
};

export const getGameById = (req: Request, res: Response) => {
  try {
    const db = readDB();
    const game = db.games.find(g => g.id === parseInt(req.params.id));
    
    if (!game) {
      return res.status(404).json({ error: 'Game not found' });
    }
    
    res.json(game);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch game' });
  }
};

export const createGame = (req: Request, res: Response) => {
  try {
    const db = readDB();
    const newGame: Game = {
      id: Math.max(0, ...db.games.map(g => g.id)) + 1,
      ...req.body,
      plays: 0,
      rating: 0,
      featured: false,
      active: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    
    db.games.push(newGame);
    writeDB(db);
    
    res.status(201).json(newGame);
  } catch (error) {
    res.status(500).json({ error: 'Failed to create game' });
  }
};

export const updateGame = (req: Request, res: Response) => {
  try {
    const db = readDB();
    const index = db.games.findIndex(g => g.id === parseInt(req.params.id));
    
    if (index === -1) {
      return res.status(404).json({ error: 'Game not found' });
    }
    
    db.games[index] = {
      ...db.games[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };
    
    writeDB(db);
    res.json(db.games[index]);
  } catch (error) {
    res.status(500).json({ error: 'Failed to update game' });
  }
};

export const deleteGame = (req: Request, res: Response) => {
  try {
    const db = readDB();
    const index = db.games.findIndex(g => g.id === parseInt(req.params.id));
    
    if (index === -1) {
      return res.status(404).json({ error: 'Game not found' });
    }
    
    db.games.splice(index, 1);
    writeDB(db);
    
    res.json({ message: 'Game deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete game' });
  }
};

export const incrementPlays = (req: Request, res: Response) => {
  try {
    const db = readDB();
    const game = db.games.find(g => g.id === parseInt(req.params.id));
    
    if (!game) {
      return res.status(404).json({ error: 'Game not found' });
    }
    
    game.plays += 1;
    game.updatedAt = new Date().toISOString();
    
    writeDB(db);
    res.json({ plays: game.plays });
  } catch (error) {
    res.status(500).json({ error: 'Failed to increment plays' });
  }
};

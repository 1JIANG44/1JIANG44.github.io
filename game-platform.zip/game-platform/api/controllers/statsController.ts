import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import type { Request, Response } from 'express';
import type { Database } from '../../src/types';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DB_PATH = path.join(__dirname, '../data/database.json');

const readDB = (): Database => {
  const data = fs.readFileSync(DB_PATH, 'utf-8');
  return JSON.parse(data);
};

export const getStats = (req: Request, res: Response) => {
  try {
    const db = readDB();
    
    const totalPlays = db.games.reduce((sum, game) => sum + game.plays, 0);
    const totalGames = db.games.filter(g => g.active).length;
    const totalCategories = db.categories.length;
    const featuredGames = db.games.filter(g => g.featured && g.active);
    const popularGames = [...db.games].sort((a, b) => b.plays - a.plays).slice(0, 5);
    
    res.json({
      totalPlays,
      totalGames,
      totalCategories,
      featuredGames,
      popularGames,
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch statistics' });
  }
};

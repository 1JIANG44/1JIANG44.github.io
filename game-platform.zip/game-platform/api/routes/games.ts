import express from 'express';
import {
  getGames,
  getGameById,
  createGame,
  updateGame,
  deleteGame,
  incrementPlays,
} from '../controllers/gamesController';

const router = express.Router();

router.get('/', getGames);
router.get('/:id', getGameById);
router.post('/', createGame);
router.put('/:id', updateGame);
router.delete('/:id', deleteGame);
router.post('/:id/play', incrementPlays);

export default router;

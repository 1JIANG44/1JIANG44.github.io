import express from 'express';
import {
  getAds,
  createAd,
  updateAd,
  deleteAd,
} from '../controllers/adsController';

const router = express.Router();

router.get('/', getAds);
router.post('/', createAd);
router.put('/:id', updateAd);
router.delete('/:id', deleteAd);

export default router;
